# This repo is just created for the benefit of DevOps aspirants.
## It contains few references related to DevOps discussions

### Slides
[click here to download the slide](slides.pdf)
### Ansible
[click here to see Ansible References](ansible)

### Jenkins
[click here to see Jenkins References](jenkins)

### Kubernetes
[click here to see Kubernetes References](kubernetes)

### Bash
[click here to see Bash References](bash)
