[pls refer this repository for more information](https://github.com/lokeshkamalay/java-tomcat-maven-example/blob/master/Jenkinsfile)
