## Assignment 1:
1. Initialize a folder as a git repository
2. Create new file
3. Add some contents to the file
4. Stage and Commit it.

## Assignment 2:
1. Modify the existing file by adding some text into it
2. Skip the stage and commit the file directly
